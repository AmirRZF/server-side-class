using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using AmirHossein_nazari.Models;

namespace AmirHossein_nazari.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult ContactUs()
    {
return View();
    }
     public IActionResult Store(Products product02)
        {
            List<Products> products = new List<Products>();


            Products product1 = new Products();
            product1.Id = 1;
            product1.NamKala = " گیتار avanda  ";
            product1.MoshakhasatKala = "جنس بدنه چوب";
            product1.Tozihat = "موجود در 3 رنگ مشکی قهوه ای و نارنجی";
            product1.DasteBandi = "آوا و موسیقی ";
            product1.Qeymat = 1550000;
            product1.Mojodi = true;
            products.Add(product1);


            Products product2 = new Products();
           product2.Id = 2;
            product2.NamKala = "گیتار amazoon  ";
            product2.MoshakhasatKala = "جنس بدنه پلاستیک";
            product2.Tozihat ="موجود در 3 رنگ مشکی قهوه ای و نارنجی";
            product2.DasteBandi = "آوا و موسیقی ";
            product2.Qeymat = 2540000;
            product2.Mojodi = true;
            products.Add(product2);


            Products product3 = new Products();
            product3.Id = 3;
            product3.NamKala = " گیتار anakonda ";
            product3.MoshakhasatKala = "جنس بدنه چوب";
            product3.Tozihat ="موجود در 3 رنگ مشکی قهوه ای و نارنجی";
            product3.DasteBandi = "آوا و موسیقی ";
            product3.Qeymat = 1750000;
            product3.Mojodi = true;
            products.Add(product3);


            Products product4 = new Products();
           product4.Id = 4;
            product4.NamKala = "گیتار vinar";
            product4.MoshakhasatKala = "جنس بدنه پلاستیک";
            product4.Tozihat ="موجود در 3 رنگ مشکی قهوه ای و نارنجی";
            product4.DasteBandi = "آوا و موسیقی ";
            product4.Qeymat = 3680000;
            product4.Mojodi = true;
            products.Add(product4);


            Products product5 = new Products();
           product5.Id = 5;
            product5.NamKala = "گیتار ahora";
            product5.MoshakhasatKala = "جنس بدنه پلاستیک و چوب";
            product5.Tozihat = "موجود در 3 رنگ مشکی قهوه ای و نارنجی";
            product5.DasteBandi = "آوا و موسیقی ";
            product5.Qeymat = 2900000;
            product5.Mojodi = true;
            products.Add(product5);


            var BOBBY = products.Where(x=>x.Mojodi).ToList();
            var sum= products.Sum(x=>x.Qeymat);
            ViewBag.Sum = sum;
            return View(BOBBY);
        }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
