﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AmirHossein_nazari.Migrations
{
    /// <inheritdoc />
    public partial class Name_1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Baskets",
                columns: table => new
                {
                    PId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PCategory = table.Column<string>(type: "nvarchar(75)", maxLength: 75, nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Baskets", x => x.PId);
                });

            migrationBuilder.CreateTable(
                name: "Productss",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NamKala = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    MoshakhasatKala = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Tozihat = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    DasteBandi = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Qeymat = table.Column<int>(type: "int", nullable: true),
                    Mojodi = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Productss", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Userss",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Family = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    password = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Userss", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Baskets");

            migrationBuilder.DropTable(
                name: "Productss");

            migrationBuilder.DropTable(
                name: "Userss");
        }
    }
}
